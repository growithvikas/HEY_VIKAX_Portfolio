const words=['Freelancer','Data Entry Specialist','Digital Entrepreneur','Shopify Expert'];
let i=0;
setInterval(()=>{
document.getElementById('typing').textContent=words[i];
i=(i+1)%words.length;
},2000);
